#pragma once
#include "uiDraw.h"

void drawLargeAsteroid(Point point, int rotation);

void drawMediumAsteroid(Point point, int rotation);

void drawSmallAsteroid(Point point, int rotation);